using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DirectorioLibros.Views.Libros
{
    public class DetallesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
