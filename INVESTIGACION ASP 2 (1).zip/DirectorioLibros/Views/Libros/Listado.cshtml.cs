using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DirectorioLibros.Views.Libros
{
    public class ListadoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
